import io, json, datetime, zipfile
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

def _draw_wrapped(c: canvas.Canvas, x: float, y: float, text: str, max_width: float, leading: float=14):
    """Very small wrapped text helper."""
    words = (text or "").split()
    line=""
    for w in words:
        test = (line + " " + w).strip()
        if c.stringWidth(test, "Helvetica", 11) <= max_width:
            line = test
        else:
            c.drawString(x, y, line)
            y -= leading
            line = w
    if line:
        c.drawString(x, y, line)
        y -= leading
    return y

def build_plan_pdf(plan_obj: dict, user_display: str="Founder", title: str="FlowForm Vitality — 4-Week Plan") -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4
    margin = 48
    y = height - margin
    c.setFont("Helvetica-Bold", 16)
    c.drawString(margin, y, title)
    y -= 22
    c.setFont("Helvetica", 11)
    c.drawString(margin, y, f"User: {user_display}    Generated: {plan_obj.get('generated_at','')[:19]}")
    y -= 18
    c.drawString(margin, y, f"Readiness: {plan_obj.get('readiness_score','-')}   Intensity: {plan_obj.get('intensity','-')}   Freq/wk: {plan_obj.get('frequency_per_week','-')}   Minutes: {plan_obj.get('minutes_per_session','-')}")
    y -= 22

    for w in (plan_obj.get("weeks") or []):
        if y < 120:
            c.showPage()
            y = height - margin
        c.setFont("Helvetica-Bold", 13)
        c.drawString(margin, y, f"Week {w.get('week')} {'(Deload)' if w.get('deload') else ''}")
        y -= 18
        c.setFont("Helvetica", 11)
        for s in (w.get("sessions") or []):
            line = f"- {s.get('title','Session')} ({s.get('minutes', '')} min) · {s.get('domain','') or s.get('style','')}"
            y = _draw_wrapped(c, margin, y, line, width - 2*margin)
            if y < 90:
                c.showPage()
                y = height - margin
                c.setFont("Helvetica", 11)
        y -= 8

    c.showPage()
    c.save()
    return buf.getvalue()

def build_week_pdf(plan_obj: dict, week: int, user_display: str="Founder") -> bytes:
    buf=io.BytesIO()
    c=canvas.Canvas(buf, pagesize=A4)
    width,height=A4
    margin=48
    y=height-margin
    c.setFont("Helvetica-Bold", 16)
    c.drawString(margin, y, f"FlowForm Vitality — Week {week}")
    y-=22
    c.setFont("Helvetica", 11)
    c.drawString(margin, y, f"User: {user_display}    Generated: {plan_obj.get('generated_at','')[:19]}")
    y-=20
    target = next((w for w in (plan_obj.get("weeks") or []) if int(w.get("week",0))==int(week)), None)
    if not target:
        c.drawString(margin, y, "Week not found in plan.")
        c.showPage(); c.save()
        return buf.getvalue()
    c.setFont("Helvetica-Bold", 12)
    c.drawString(margin, y, f"Intensity: {plan_obj.get('intensity','-')}   Minutes: {plan_obj.get('minutes_per_session','-')}")
    y-=18
    c.setFont("Helvetica", 11)
    for s in (target.get("sessions") or []):
        line=f"- {s.get('title','Session')} ({s.get('minutes','')} min) · {s.get('progression','')}"
        y=_draw_wrapped(c, margin, y, line, width-2*margin)
        if y < 90:
            c.showPage()
            y=height-margin
            c.setFont("Helvetica", 11)
    c.showPage(); c.save()
    return buf.getvalue()

def build_export_zip(plan_obj: dict, ics_text: str, user_display: str="Founder") -> bytes:
    buf=io.BytesIO()
    with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("plan_4week.json", json.dumps(plan_obj, indent=2))
        z.writestr("schedule.ics", ics_text)
        z.writestr("plan_4week.pdf", build_plan_pdf(plan_obj, user_display=user_display))
        z.writestr("week1.pdf", build_week_pdf(plan_obj, week=1, user_display=user_display))
    return buf.getvalue()
