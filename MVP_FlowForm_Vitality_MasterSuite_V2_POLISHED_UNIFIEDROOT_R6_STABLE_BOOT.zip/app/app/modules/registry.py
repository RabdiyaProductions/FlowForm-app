
import datetime, random, os, json

# External session variant library (Mega-Wave Content Depth)
_EXTERNAL_VARIANTS = None

def _load_external_variants():
    global _EXTERNAL_VARIANTS
    if _EXTERNAL_VARIANTS is not None:
        return _EXTERNAL_VARIANTS
    try:
        base = os.path.dirname(os.path.dirname(__file__))
        path = os.path.join(base, "content", "session_variants.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                _EXTERNAL_VARIANTS = json.load(f) or {}
        else:
            _EXTERNAL_VARIANTS = {}
    except Exception:
        _EXTERNAL_VARIANTS = {}
    return _EXTERNAL_VARIANTS

DOMAINS = [
  {"key":"strength","name":"Strength","intensity":"med"},
  {"key":"mobility","name":"Mobility","intensity":"low"},
  {"key":"recovery","name":"Recovery","intensity":"low"},
  {"key":"hiit","name":"HIIT","intensity":"high"},
  {"key":"nutrition","name":"Nutrition","intensity":"low"},
  {"key":"taichi","name":"Tai Chi","intensity":"low"},
  {"key":"performance","name":"Performance","intensity":"med"},
  {"key":"flexibility","name":"Flexibility","intensity":"low"},
  {"key":"endurance","name":"Endurance","intensity":"med"},
  {"key":"bodyweight","name":"Bodyweight","intensity":"med"},
  {"key":"hypertrophy","name":"Hypertrophy","intensity":"med"},
  {"key":"martial_arts","name":"Martial Arts Conditioning","intensity":"high"},
  {"key":"longevity","name":"Longevity / Vital Age","intensity":"low"},
  {"key":"core","name":"Core / Stability","intensity":"med"},
]

INJURY_FLAGS = {
  "knee":{"avoid":["hiit","martial_arts","endurance"]},
  "shoulder":{"avoid":["hypertrophy","strength"]},
  "back":{"avoid":["hiit","hypertrophy"]},
  "wrist":{"avoid":["bodyweight","martial_arts"]}
}

def normalize_injuries(injuries_text: str):
    if not injuries_text: return set()
    t=injuries_text.lower()
    flags=set()
    for k in INJURY_FLAGS.keys():
        if k in t:
            flags.add(k)
    return flags

def allowed_domains(injuries_text: str):
    flags=normalize_injuries(injuries_text)
    avoid=set()
    for f in flags:
        avoid.update(INJURY_FLAGS[f]["avoid"])
    return [d for d in DOMAINS if d["key"] not in avoid]

def exercise_templates(domain_key: str, level: str):
    """Curated templates with light variation (mobile-friendly).
    Returns list of {name, prescription}.
    """
    external = _load_external_variants()
    if isinstance(external, dict) and domain_key in external:
        try:
            v = external.get(domain_key) or []
            if isinstance(v, list) and v:
                return [list(x) for x in v]
        except Exception:
            pass

    variants = {
      "strength":[
        [
          ("Warm-up · joint prep + breath", "8 min"),
          ("Squat pattern", "4x6-8"),
          ("Hinge pattern", "4x6-8"),
          ("Push", "3x8"),
          ("Pull", "3x10"),
          ("Core · brace", "6 min"),
          ("Cool-down", "5 min")
        ],
        [
          ("Warm-up · mobility flow", "8 min"),
          ("Split squat / lunge", "4x8"),
          ("RDL / hinge", "4x8"),
          ("Overhead / incline press", "3x8"),
          ("Row / pull", "3x10"),
          ("Carry", "6 min"),
          ("Cool-down", "5 min")
        ],
      ],
      "hypertrophy":[
        [
          ("Warm-up · pump prep", "6 min"),
          ("Press", "4x10"),
          ("Row", "4x10"),
          ("Leg press / squat", "4x12"),
          ("Accessory superset", "3x12"),
          ("Core finisher", "6 min"),
          ("Cool-down", "5 min")
        ],
        [
          ("Warm-up · tissue + activation", "6 min"),
          ("Pull", "4x10"),
          ("Push", "4x10"),
          ("Hinge or split squat", "4x12"),
          ("Arms/shoulders superset", "3x12"),
          ("Core finisher", "6 min"),
          ("Cool-down", "5 min")
        ],
      ],
      "hiit":[
        [
          ("Warm-up · breath + mobility", "8 min"),
          ("Intervals", "10x(30s/60s)"),
          ("Skill rounds", "6x(45s/45s)"),
          ("Finisher", "6 min"),
          ("Cool-down", "6 min")
        ],
        [
          ("Warm-up · movement prep", "8 min"),
          ("EMOM", "12 min"),
          ("Rounds", "6x2 min"),
          ("Finisher", "5 min"),
          ("Cool-down", "6 min")
        ],
      ],
      "endurance":[
        [
          ("Warm-up", "6 min"),
          ("Steady state (Zone 2)", "30-45 min"),
          ("Pickups", "6x20s"),
          ("Cool-down", "6 min")
        ],
        [
          ("Warm-up", "6 min"),
          ("Progression", "35-50 min"),
          ("Strides", "6x20s"),
          ("Cool-down", "6 min")
        ],
      ],
      "mobility":[
        [
          ("Breath reset", "2 min"),
          ("Hips", "10 min"),
          ("T-spine", "8 min"),
          ("Ankles", "6 min"),
          ("Core control", "6 min")
        ],
        [
          ("Breath reset", "2 min"),
          ("Shoulders", "8 min"),
          ("Hips", "10 min"),
          ("Spine", "6 min"),
          ("Core control", "6 min")
        ],
      ],
      "flexibility":[
        [
          ("Breath downshift", "3 min"),
          ("Hamstrings", "8 min"),
          ("Hip flexors", "8 min"),
          ("Shoulders", "6 min"),
          ("Spine decompression", "5 min")
        ],
        [
          ("Breath downshift", "3 min"),
          ("Hips", "10 min"),
          ("Calves/ankles", "6 min"),
          ("Shoulders", "6 min"),
          ("Spine decompression", "5 min")
        ],
      ],
      "recovery":[
        [
          ("Breathing", "5 min"),
          ("Easy walk", "20 min"),
          ("Soft tissue / mobility", "10 min"),
          ("Sleep routine", "5 min")
        ],
        [
          ("Breathing", "6 min"),
          ("Easy cycle / walk", "20 min"),
          ("Mobility", "12 min"),
          ("Downshift", "4 min")
        ],
      ],
      "core":[
        [
          ("Breath brace", "3 min"),
          ("Anti-rotation", "3x10"),
          ("Hinge brace", "3x20s"),
          ("Side plank", "3x30s"),
          ("Carry / march", "6 min")
        ],
        [
          ("Breath brace", "3 min"),
          ("Dead bug / hollow", "3x10"),
          ("Side plank", "3x30s"),
          ("Anti-extension", "3x10"),
          ("Carry / march", "6 min")
        ],
      ],
      "bodyweight":[
        [
          ("Warm-up", "6 min"),
          ("Push-ups", "3xAMRAP"),
          ("Split squat", "3x10"),
          ("Rows", "3x10"),
          ("Plank", "3x45s"),
          ("Cool-down", "6 min")
        ],
        [
          ("Warm-up", "6 min"),
          ("Tempo squats", "3x10"),
          ("Push-ups", "3xAMRAP"),
          ("Hip hinge", "3x12"),
          ("Plank/side plank", "6 min"),
          ("Cool-down", "6 min")
        ],
      ],
      "taichi":[
        [
          ("Warm-up · joint circles", "8-10 min"),
          ("Form practice", "20 min"),
          ("Silk reeling / flow", "10 min"),
          ("Breath work", "5 min")
        ],
      ],
      "performance":[
        [
          ("Power prep", "10 min"),
          ("Strength-speed", "3x5"),
          ("Jumps / throws", "8 min"),
          ("Conditioning", "12 min"),
          ("Cool-down", "6 min")
        ],
        [
          ("Power prep", "10 min"),
          ("Sprint mechanics", "10 min"),
          ("Explosive circuit", "10 min"),
          ("Conditioning", "10 min"),
          ("Cool-down", "6 min")
        ],
      ],
      "martial_arts":[
        [
          ("Footwork", "10 min"),
          ("Technique", "12 min"),
          ("Rounds", "6x2 min"),
          ("Conditioning", "10 min"),
          ("Core finisher", "8 min")
        ],
        [
          ("Footwork", "8 min"),
          ("Technique", "14 min"),
          ("Rounds", "8x90s"),
          ("Conditioning", "10 min"),
          ("Core finisher", "8 min")
        ],
      ],
      "longevity":[
        [
          ("Zone 2", "25 min"),
          ("Mobility", "10 min"),
          ("Balance", "8 min"),
          ("Breath downshift", "5 min")
        ],
        [
          ("Zone 2", "20 min"),
          ("Mobility", "12 min"),
          ("Balance", "10 min"),
          ("Breath downshift", "5 min")
        ],
      ]
    }

    # deterministic variation seed (keeps plans stable day-to-day)
    seed = f"{datetime.date.today().strftime('%Y-%m')}-{domain_key}-{level}"
    random.seed(seed)
    choices = variants.get(domain_key) or [[("General movement", "20 min")]]
    choice = random.choice(choices)

    # small level tweak
    lvl = (level or "beginner").lower()
    if lvl in ("advanced","intermediate") and domain_key in ("strength","hypertrophy","bodyweight"):
        def bump(r):
            if r.startswith("3x"):
                return r.replace("3x","4x",1)
            return r
        choice = [(n, bump(r)) for n,r in choice]

    return [{"name":n,"prescription":r} for n,r in choice]


def pick_monthly_variations(month_key: str, available_keys: list[str], count:int=2):
    random.seed(month_key)
    keys=[k for k in available_keys if k not in ("nutrition",)]
    random.shuffle(keys)
    return keys[:count]

def intensity_from_readiness(readiness_score: int, adherence_pct: int):
    # readiness_score 0-100
    if readiness_score < 45 or adherence_pct < 40:
        return "Easy"
    if readiness_score > 70 and adherence_pct > 70:
        return "Hard"
    return "Normal"