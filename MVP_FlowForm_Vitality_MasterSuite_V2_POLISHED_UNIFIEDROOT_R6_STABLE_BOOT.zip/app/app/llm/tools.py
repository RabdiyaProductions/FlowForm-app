import json

SYSTEM_FOUNDER = """You are FlowForm Vitality Founder Coach.
You help the founder with mind, body, and soul development at home.
You are safety-minded: avoid medical diagnosis; avoid dangerous advice.
Be concise, practical, and supportive.
When asked for structured output, return valid JSON only.
"""

def _tone_block(vibe: str, cue_frequency: str, mode: str) -> str:
    vibe=(vibe or "balanced").lower()
    cue_frequency=(cue_frequency or "medium").lower()
    mode=(mode or "auto").lower()
    return (
        f"Tone/vibe: {vibe}. "
        f"Cue frequency: {cue_frequency}. "
        f"Mode: {mode} (directed=more guidance; cockpit=more autonomy). "
        "Always include at least one core stability cue and one breath/focus cue."
    )

def build_session_script_prompt(session: dict, profile: dict|None, intake: dict|None, readiness: int, settings: dict|None=None):
    settings=settings or {}
    vibe=(settings.get("coach_style") or intake.get("coach_style") or "balanced")
    cue_frequency=(settings.get("cue_frequency") or "medium")
    mode=(settings.get("directed_mode_override") or "auto")
    tone=_tone_block(vibe, cue_frequency, mode)

    payload={
        "profile": profile or {},
        "intake": intake or {},
        "readiness": readiness,
        "settings": {k: settings.get(k) for k in ("intensity_dial","recovery_governor","cue_frequency","coach_style","directed_mode_override") if settings.get(k) is not None},
        "session": session or {}
    }

    return [
        {"role":"system","content": SYSTEM_FOUNDER + "\n" + tone},
        {"role":"user","content": (
            "Create a short coaching script for this at-home session. "
            "Return JSON only with keys: warmup, main, cooldown, mindset, safety. "
            "Each of warmup/main/cooldown should be a list of short cue strings. "
            "Mindset should be 2 short prompts. Safety should be 2 short reminders.\n\n"
            f"CONTEXT_JSON: {json.dumps(payload, ensure_ascii=False)}"
        )}
    ]

def build_week_summary_prompt(context: dict, profile: dict|None=None, settings: dict|None=None):
    settings=settings or {}
    vibe=(settings.get("coach_style") or "balanced")
    cue_frequency=(settings.get("cue_frequency") or "medium")
    mode=(settings.get("directed_mode_override") or "auto")
    tone=_tone_block(vibe, cue_frequency, mode)

    payload={
        "profile": profile or {},
        "settings": {k: settings.get(k) for k in ("intensity_dial","recovery_governor","cue_frequency","coach_style","directed_mode_override") if settings.get(k) is not None},
        "context": context or {}
    }

    return [
        {"role":"system","content": SYSTEM_FOUNDER + "\n" + tone},
        {"role":"user","content": (
            "Summarise the week and provide next-week adjustments. "
            "Return JSON only with keys: summary, wins, risks, next_week_focus, adjustments.\n\n"
            f"CONTEXT_JSON: {json.dumps(payload, ensure_ascii=False)}"
        )}
    ]
