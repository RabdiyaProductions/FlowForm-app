"""Phase B — Offline AI Gateway (deterministic).

This module is deliberately local-first and offline by default.
It provides:
- GET /api/ai/selfcheck
- POST /api/ai/demo

No external network calls are made.
"""

from __future__ import annotations
import hashlib
import json
import time
from typing import Any, Dict

def _stable_id(*parts: str) -> str:
    h = hashlib.sha256()
    for p in parts:
        h.update((p or "").encode("utf-8"))
        h.update(b"\n")
    return h.hexdigest()[:12]

def _offline_reply(prompt: str, system: str = "") -> Dict[str, Any]:
    job_id = _stable_id(system, prompt, "offline")
    # Deterministic pseudo-response: short, safe, and obviously offline.
    summary = (prompt or "").strip().replace("\n", " ")[:220]
    if not summary:
        summary = "(empty prompt)"
    return {
        "mode": "offline",
        "job_id": job_id,
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "input": {"system": system or "", "prompt": prompt or ""},
        "output": {
            "text": f"[OFFLINE_AI:{job_id}] {summary}",
            "tokens_est": max(1, len((system or "") + (prompt or "")) // 4),
        },
    }

def register_phase_b_ai(app) -> None:
    """Register Phase B AI routes onto a Flask app."""
    try:
        from flask import request, jsonify
    except Exception:
        return  # Not Flask; fail-open.

    @app.get("/api/ai/selfcheck")
    def _ai_selfcheck():
        return jsonify({
            "ok": True,
            "phase": "B",
            "ai": {"mode": "offline", "provider": "none"},
        })

    @app.post("/api/ai/demo")
    def _ai_demo():
        payload = {}
        try:
            payload = request.get_json(silent=True) or {}
        except Exception:
            payload = {}
        prompt = str(payload.get("prompt", ""))
        system = str(payload.get("system", ""))
        return jsonify(_offline_reply(prompt=prompt, system=system))
