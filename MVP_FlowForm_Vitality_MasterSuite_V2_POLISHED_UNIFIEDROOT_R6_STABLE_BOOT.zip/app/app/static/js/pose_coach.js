/* FlowForm Pose Coach (Founder/local-first) — Phase 2
   Goals:
   - Movement-aware coaching signals (posture / squat / hinge / plank / balance / guard).
   - Simple overlay skeleton + angle guides (lightweight, no heavy deps).
   - Optional MediaPipe Pose via CDN; graceful offline fallback.
   Notes:
   - This is NOT medical advice. It provides technique cues only.
*/
let __poseEnabled = false;
let __pose = null;
let __camera = null;
let __videoEl = null;
let __overlay = null;
let __ctx = null;
let __lastSignals = [];
let __baseline = null; // calibration baseline (shoulder width etc.)

function $(id){ return document.getElementById(id); }
function setPoseStatus(msg){ const el=$('poseStatus'); if(el) el.textContent = msg; }
function setSignals(items){
  const ul=$('poseSignals'); if(!ul) return;
  __lastSignals = (items||[]).slice(0,8);
  ul.innerHTML = '';
  __lastSignals.forEach(t=>{
    const li=document.createElement('li'); li.textContent=t; ul.appendChild(li);
  });
  const hidden=$('pose_signals'); if(hidden) hidden.value = __lastSignals.join(" | ");
}
function getMode(){
  const sel=$('poseMode');
  return (sel && sel.value) ? sel.value : 'posture';
}
function getDiscipline(){
  // Optional discipline selector (if present), else infer from document title.
  const sel=$('poseDiscipline');
  if(sel && sel.value) return sel.value;
  const t=(document.title||'').toLowerCase();
  if(t.includes('boxing')) return 'boxing';
  if(t.includes('muay')) return 'muay_thai';
  if(t.includes('combat')) return 'combat';
  if(t.includes('yoga')) return 'yoga';
  if(t.includes('pilates')) return 'pilates';
  if(t.includes('tai')) return 'tai_chi';
  if(t.includes('balance')) return 'balance';
  if(t.includes('hiit')) return 'hiit';
  if(t.includes('bollywood')) return 'bollywood';
  return 'general';
}

function ensureOverlay(){
  __videoEl = $('v');
  __overlay = $('overlay');
  if(!__videoEl || !__overlay) return false;
  const rect = __videoEl.getBoundingClientRect();
  const dpr = (window.devicePixelRatio||1);
  __overlay.width = Math.max(360, Math.floor(rect.width * dpr));
  __overlay.height = Math.max(240, Math.floor((rect.width * 0.5625) * dpr));
  __ctx = __overlay.getContext('2d');
  return true;
}

async function loadMediaPipePose(){
  const urls = [
    'https://cdn.jsdelivr.net/npm/@mediapipe/pose/pose.js',
    'https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js'
  ];
  const loadScript = (src)=> new Promise((resolve,reject)=>{
    const s=document.createElement('script'); s.src=src; s.async=true;
    s.onload=()=>resolve(true); s.onerror=()=>reject(new Error('failed '+src));
    document.head.appendChild(s);
  });
  for (const u of urls){ await loadScript(u); }
  return true;
}

function landmark(lm, idx){
  if(!lm || !lm[idx]) return null;
  const p=lm[idx];
  if(p.visibility!=null && p.visibility < 0.45) return null;
  return p;
}
function dist(a,b){
  if(!a||!b) return null;
  return Math.hypot(a.x-b.x, a.y-b.y);
}
function angle(a,b,c){
  if(!a||!b||!c) return null;
  const ab = {x:a.x-b.x, y:a.y-b.y};
  const cb = {x:c.x-b.x, y:c.y-b.y};
  const dot = ab.x*cb.x + ab.y*cb.y;
  const mag1 = Math.hypot(ab.x,ab.y);
  const mag2 = Math.hypot(cb.x,cb.y);
  if(mag1===0||mag2===0) return null;
  let cos = dot/(mag1*mag2);
  cos = Math.max(-1, Math.min(1, cos));
  return Math.acos(cos) * 180/Math.PI;
}

function calBaseline(lm){
  // baseline from neutral stance (shoulders/hips width)
  const LS=landmark(lm,11), RS=landmark(lm,12), LH=landmark(lm,23), RH=landmark(lm,24);
  const sw=dist(LS,RS), hw=dist(LH,RH);
  if(sw && hw){
    __baseline = { sw, hw, ts: Date.now() };
  }
}

function skeletonPairs(){
  // lightweight skeleton connections (indices)
  return [
    [11,12],[11,23],[12,24],[23,24],
    [23,25],[25,27],[24,26],[26,28],
    [11,13],[13,15],[12,14],[14,16],
  ];
}

function drawOverlay(lm){
  if(!__ctx || !__overlay){ return; }
  __ctx.clearRect(0,0,__overlay.width,__overlay.height);
  if(!lm) return;

  const w=__overlay.width, h=__overlay.height;
  const dpr=(window.devicePixelRatio||1);

  // Skeleton lines
  __ctx.lineWidth = 2*dpr;
  __ctx.strokeStyle = 'rgba(0,255,200,0.75)';
  for(const [a,b] of skeletonPairs()){
    const p=landmark(lm,a), q=landmark(lm,b);
    if(!p||!q) continue;
    __ctx.beginPath();
    __ctx.moveTo(p.x*w, p.y*h);
    __ctx.lineTo(q.x*w, q.y*h);
    __ctx.stroke();
  }

  // Dots
  __ctx.fillStyle = 'rgba(255,255,255,0.85)';
  for (let i=0;i<lm.length;i++){
    const p=landmark(lm,i);
    if(!p) continue;
    __ctx.beginPath();
    __ctx.arc(p.x*w, p.y*h, 3.5*dpr, 0, Math.PI*2);
    __ctx.fill();
  }

  // Mode hint text
  __ctx.fillStyle = 'rgba(255,255,255,0.75)';
  __ctx.font = `${12*dpr}px system-ui, -apple-system, Segoe UI, Roboto, Arial`;
  __ctx.fillText(`Mode: ${getMode().replace('_',' ')}`, 12*dpr, 18*dpr);
}

function computeSignals(lm){
  // MediaPipe indices:
  // 11/12 shoulders, 23/24 hips, 25/26 knees, 27/28 ankles, 13/14 elbows, 15/16 wrists, 0 nose
  const LS=landmark(lm,11), RS=landmark(lm,12), LH=landmark(lm,23), RH=landmark(lm,24);
  const LK=landmark(lm,25), RK=landmark(lm,26), LA=landmark(lm,27), RA=landmark(lm,28);
  const LE=landmark(lm,13), RE=landmark(lm,14), LW=landmark(lm,15), RW=landmark(lm,16);
  const N = landmark(lm,0);

  const sig=[];
  const mode=getMode();
  const discipline=getDiscipline();

  // Common: posture symmetry
  if(LS&&RS){
    const dy = Math.abs(LS.y - RS.y);
    if(dy > 0.06) sig.push('Posture: level your shoulders. Tall spine, soften ribs.');
  }
  if(LH&&RH){
    const dy = Math.abs(LH.y - RH.y);
    if(dy > 0.06) sig.push('Posture: hips look uneven. Reset stance width and pelvis level.');
  }

  // Knee / hip angles
  const leftK = angle(LH,LK,LA);
  const rightK = angle(RH,RK,RA);
  const leftH = (LS&&LH&&LK) ? angle(LS,LH,LK) : null;
  const rightH= (RS&&RH&&RK) ? angle(RS,RH,RK) : null;

  const knee = [leftK,rightK].filter(v=>v!=null);
  const hip  = [leftH,rightH].filter(v=>v!=null);
  const kAvg = knee.length ? knee.reduce((a,b)=>a+b,0)/knee.length : null;
  const hAvg = hip.length  ? hip.reduce((a,b)=>a+b,0)/hip.length  : null;

  // Baseline calibration: if no baseline and in posture mode, set it when stable
  if(!__baseline && mode==='posture' && LS&&RS&&LH&&RH) calBaseline(lm);

  if(mode==='squat'){
    if(kAvg!=null){
      if(kAvg > 165) sig.push('Squat: start with a controlled sit-back. Aim for knees to bend smoothly.');
      else if(kAvg > 135) sig.push('Squat: good range. If comfortable, deepen towards parallel with control.');
      else sig.push('Squat: deep range detected. Keep knees tracking over toes.');
    }
    // Knee tracking proxy: knee vs ankle x alignment
    if(LK&&LA){
      const dx = (LK.x - LA.x);
      if(Math.abs(dx) > 0.08) sig.push('Squat: check knee tracking—aim knees over mid-foot (avoid collapsing in/out).');
    }
    sig.push('Cue: inhale to brace, exhale as you drive up. Ribs stacked over pelvis.');
  }

  if(mode==='hinge'){
    if(hAvg!=null){
      if(hAvg > 165) sig.push('Hinge: try a stronger hip-hinge (push hips back) rather than bending only at the knees.');
      else if(hAvg > 140) sig.push('Hinge: decent hinge. Keep spine long, neck neutral.');
      else sig.push('Hinge: strong hinge angle. Keep lats on, spine neutral, weight mid-foot.');
    }
    sig.push('Cue: “hips back, long spine, soft knees”.');
  }

  if(mode==='plank'){
    // Hip sag/ pike proxy: hip y relative to shoulders and ankles
    if(LS&&RS&&LH&&RH&&LA&&RA){
      const shY=(LS.y+RS.y)/2, hipY=(LH.y+RH.y)/2, anY=(LA.y+RA.y)/2;
      // In a good plank, hipY ~ mid between shY and anY (rough proxy)
      const target = (shY+anY)/2;
      if(hipY - target > 0.06) sig.push('Plank: hips are sagging. Squeeze glutes, brace, push floor away.');
      else if(target - hipY > 0.06) sig.push('Plank: hips are high. Lower slightly, keep ribs down.');
      else sig.push('Plank: good line. Maintain gentle brace and steady breathing.');
    }
    sig.push('Cue: exhale gently, brace 20–30%, keep neck long.');
  }

  if(mode==='balance'){
    if(LH&&RH){
      const dy=Math.abs(LH.y-RH.y);
      if(dy>0.05) sig.push('Balance: hips are tipping. Slow down and find tripod foot contact.');
      else sig.push('Balance: hips level. Keep soft knee, tall posture.');
    }
    sig.push('Cue: steady breath, eyes soft focus, brace lightly.');
  }

  if(mode==='guard'){
    // Guard proxy: wrists near face level, elbows down
    if(N && LW && RW){
      const faceY = N.y;
      const wAvgY = (LW.y+RW.y)/2;
      if(wAvgY - faceY > 0.10) sig.push('Guard: hands a bit low. Bring gloves up—cheekbone height.');
      else sig.push('Guard: hands up—nice. Keep chin tucked lightly.');
    }
    if(LE&&LW && RE&&RW){
      const lElbowDown = (LE.y < LW.y);
      const rElbowDown = (RE.y < RW.y);
      if(!(lElbowDown && rElbowDown)) sig.push('Guard: elbows drifting—keep elbows “heavy” and close to ribs.');
    }
    if(discipline==='boxing' || discipline==='combat' || discipline==='muay_thai'){
      sig.push('Cue: breathe out on strikes, relax shoulders, rotate from core.');
    }else{
      sig.push('Cue: ribs stacked, light brace, smooth exhale.');
    }
  }

  if(mode==='posture'){
    if(kAvg!=null && kAvg < 150) sig.push('Posture: knees bent—stand tall if you’re doing a neutral snapshot.');
    if(__baseline && __baseline.sw && LS&&RS){
      const sw=dist(LS,RS);
      if(sw && sw < __baseline.sw*0.85) sig.push('Posture: shoulders look rounded. Open chest gently, widen collarbones.');
    }
    sig.push('Core cue: exhale softly, brace 20–30%, ribs stacked over pelvis.');
  }

  // Keep signals concise (avoid nagging)
  if(sig.length===0){
    sig.push('Pose coach: hold steady for 2–3 seconds for better readings.');
    sig.push('Core cue: exhale softly, brace 20–30%, ribs stacked over pelvis.');
  }
  return sig.slice(0,7);
}

async function startPoseCoach(){
  if(!ensureOverlay()){
    setPoseStatus('Pose coach unavailable (missing video).');
    return;
  }
  try{
    setPoseStatus('Loading pose coach…');
    await loadMediaPipePose();
    setPoseStatus('Pose coach loaded. Starting…');
    // eslint-disable-next-line no-undef
    __pose = new Pose.Pose({locateFile: (file)=>`https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`});
    __pose.setOptions({
      modelComplexity: 1,
      smoothLandmarks: true,
      enableSegmentation: false,
      minDetectionConfidence: 0.55,
      minTrackingConfidence: 0.55
    });
    __pose.onResults((results)=>{
      if(!__poseEnabled) return;
      const lm = results.poseLandmarks;
      drawOverlay(lm);
      const sig = computeSignals(lm);
      setSignals(sig);
      const modeHidden=$('pose_mode'); if(modeHidden) modeHidden.value = getMode();
      const discHidden=$('pose_discipline'); if(discHidden) discHidden.value = getDiscipline();
    });
    // eslint-disable-next-line no-undef
    __camera = new Camera(__videoEl, {
      onFrame: async ()=>{ if(__poseEnabled && __pose){ await __pose.send({image: __videoEl}); } },
      width: 640,
      height: 360
    });
    __camera.start();
    setPoseStatus('Pose coach running (beta).');
  } catch(e){
    console.warn(e);
    __poseEnabled = false;
    const t=$('poseToggle'); if(t) t.checked=false;
    setPoseStatus('Pose coach could not load (offline?). Your check‑in still works.');
    setSignals(['Pose coach failed to load. Run once with internet access to fetch the libraries.']);
  }
}

function stopPoseCoach(){
  try{ if(__camera && __camera.stop) __camera.stop(); }catch(e){}
  __camera = null;
  __pose = null;
  if(__ctx && __overlay) __ctx.clearRect(0,0,__overlay.width,__overlay.height);
  setPoseStatus('Pose coach is off.');
  setSignals(['Pose coach is off.']);
}

window.togglePoseCoach = function(enabled){
  __poseEnabled = !!enabled;
  if(__poseEnabled) startPoseCoach();
  else stopPoseCoach();
};

// Keep overlay sized on rotation
window.addEventListener('resize', ()=>{ if(__poseEnabled) ensureOverlay(); });
