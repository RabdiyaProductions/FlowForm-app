import datetime
from collections import defaultdict

def _parse_date(s: str):
    try:
        y,m,d = [int(x) for x in s.split("-")]
        return datetime.date(y,m,d)
    except Exception:
        return None

def compute_streak(logs):
    """Compute current streak of completed sessions ending today or yesterday."""
    # logs: list dict with date, status
    completed = sorted({l.get("date") for l in logs if (l.get("status") or "").lower()=="completed" and l.get("date")}, reverse=True)
    if not completed:
        return 0
    today = datetime.date.today()
    streak = 0
    cursor = today
    # allow streak to start yesterday if none today
    if completed and _parse_date(completed[0]) != today:
        cursor = today - datetime.timedelta(days=1)
    while True:
        ds = cursor.isoformat()
        if ds in completed:
            streak += 1
            cursor = cursor - datetime.timedelta(days=1)
            continue
        break
    return streak

def completion_rate(logs, days: int):
    """Completed sessions / total logged sessions within window."""
    cutoff = datetime.date.today() - datetime.timedelta(days=days)
    total=0
    comp=0
    for l in logs:
        d=_parse_date(l.get("date") or "")
        if not d or d < cutoff: 
            continue
        total += 1
        if (l.get("status") or "").lower()=="completed":
            comp += 1
    return {"completed": comp, "total": total, "pct": int(round((comp/total)*100)) if total else 0}

def rpe_stats(logs, days: int=30):
    cutoff = datetime.date.today() - datetime.timedelta(days=days)
    rpes=[]
    for l in logs:
        d=_parse_date(l.get("date") or "")
        if not d or d < cutoff: 
            continue
        r=l.get("rpe")
        if r is None: 
            continue
        try:
            r=int(r)
            if 1 <= r <= 10:
                rpes.append(r)
        except Exception:
            pass
    if not rpes:
        return {"avg": None, "min": None, "max": None, "count": 0}
    return {"avg": round(sum(rpes)/len(rpes),1), "min": min(rpes), "max": max(rpes), "count": len(rpes)}

def readiness_trend(recoveries, days: int=14):
    """Return list of (date, readiness_score)."""
    cutoff = datetime.date.today() - datetime.timedelta(days=days)
    out=[]
    for r in recoveries:
        ts = r.get("created_at") or r.get("ts")
        # ts can be ISO; derive date
        d=None
        if ts:
            try:
                d = datetime.datetime.fromisoformat(ts.replace("Z","")).date()
            except Exception:
                pass
        if not d:
            continue
        if d < cutoff:
            continue
        sleep = (r.get("sleep") or 6) * 10
        energy = (r.get("energy") or 6) * 10
        stress = (r.get("stress") or 5) * 10
        soreness = (r.get("soreness") or 5) * 10
        steps = min((r.get("steps") or 6000)/100, 100)
        score = 0.28*sleep + 0.28*energy + 0.18*(100-stress) + 0.18*(100-soreness) + 0.08*steps
        out.append((d.isoformat(), int(round(max(0,min(100,score))))))
    out.sort(key=lambda x:x[0])
    return out

def domain_diversity(plan_obj):
    dom=set()
    for w in (plan_obj or {}).get("weeks",[]):
        for s in (w.get("sessions") or []):
            if s.get("domain"):
                dom.add(s["domain"])
            elif s.get("style"):
                dom.add(s["style"])
    return sorted(dom)

def weekly_load(logs, days:int=28):
    """Simple load metric: sum(duration_min * rpe) per week bucket."""
    cutoff = datetime.date.today() - datetime.timedelta(days=days)
    buckets=defaultdict(int)
    for l in logs:
        d=_parse_date(l.get("date") or "")
        if not d or d < cutoff:
            continue
        r=l.get("rpe") or 0
        dur=l.get("duration_min") or 0
        try:
            r=int(r); dur=int(dur)
        except Exception:
            continue
        week_start = (d - datetime.timedelta(days=d.weekday())).isoformat()
        buckets[week_start] += max(0, dur) * max(0, r)
    out=[{"week_start":k,"load":v} for k,v in sorted(buckets.items(), key=lambda x:x[0])]
    return out
