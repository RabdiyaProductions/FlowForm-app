
import datetime, math, random
from modules.registry import allowed_domains, intensity_from_readiness, pick_monthly_variations, exercise_templates
# ===== Mega-Wave Progression Ladders (v1) =====
import os, json
_PROG_LADDERS = None
def _load_progression_ladders():
    global _PROG_LADDERS
    if _PROG_LADDERS is not None:
        return _PROG_LADDERS
    try:
        base = os.path.dirname(__file__)
        p = os.path.join(base, "content", "progression_ladders.json")
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                _PROG_LADDERS = json.load(f) or {}
        else:
            _PROG_LADDERS = {}
    except Exception:
        _PROG_LADDERS = {}
    return _PROG_LADDERS

def _week_policy(week_no: int):
    ladd = _load_progression_ladders()
    w = (ladd.get("weeks") or {}).get(str(int(week_no))) or {}
    return {
        "tag": w.get("tag") or ("Deload" if int(week_no)==4 else "Normal"),
        "minute_factor": float(w.get("minute_factor") or (0.75 if int(week_no)==4 else 1.0)),
        "intensity_bias": int(w.get("intensity_bias") or ( -6 if int(week_no)==4 else 0)),
        "prefer_low_domains": bool(w.get("prefer_low_domains") or False),
    }


def apply_recovery_governor(readiness: int, recovery_governor: str, recent_recovery: dict|None, checkin_rating: str|None):
    """Adjust readiness based on recovery governor + check-in + recovery flags."""
    gov=(recovery_governor or "Balanced").strip().lower()
    bias={"strict":-8,"balanced":0,"loose":4}.get(gov,0)

    # check-in: too_much => pull down; too_easy => allow up
    if checkin_rating == "too_much":
        bias -= 10
    elif checkin_rating == "too_easy":
        bias += 6

    # recovery flags (soft)
    if recent_recovery:
        sleep = recent_recovery.get("sleep") or 6
        stress = recent_recovery.get("stress") or 5
        soreness = recent_recovery.get("soreness") or 5
        if sleep <= 4:
            bias -= 10
        if stress >= 8:
            bias -= 8
        if soreness >= 8:
            bias -= 8

    return int(max(0, min(100, readiness + bias)))

def build_plan_from_templates(templates: list[dict], frequency: int, minutes: int):
    """Create a 4-week plan from trainer templates (programme engine v1)."""
    # pick templates ordered by recency; select up to frequency unique items
    chosen=[]
    for t in templates:
        if len(chosen) >= frequency:
            break
        chosen.append(t)
    if not chosen:
        return None
    weeks=[]
    for w in range(1,5):
        deload=(w==4)
        policy = _week_policy(w)
        sessions=[]
        for idx,t in enumerate(chosen, start=1):
            base_min = int(t.get("duration_min") or minutes)
            mins = int(round(base_min * float(policy.get('minute_factor') or 1.0)))
            if deload:
                mins = max(20, mins)
            style = (t.get("style") or "balanced")
            title = (t.get("title") or "Session")
            tag = policy.get('tag') or "Normal"
            if deload: tag = policy.get('tag') or "Deload"
            elif w==2: tag="Volume+"
            elif w==3: tag="Intensity+"
            sessions.append({
                "id": f"W{w}-T{t.get('id')}",
                "domain": style,
                "title": title,
                "minutes": mins,
                "progression": tag,
                "template_id": int(t.get("id")),
                "blocks": t.get("blocks") or []
            })
        weeks.append({"week":w,"deload":deload,"sessions":sessions})
    plan={
        "generated_at": datetime.datetime.utcnow().isoformat(),
        "readiness_score": None,
        "intensity": None,
        "frequency_per_week": frequency,
        "minutes_per_session": minutes,
        "weeks": weeks,
        "policy": {"programme_engine":"trainer_templates_v1"}
    }
    return plan

def compute_readiness(recovery_row: dict|None):
    if not recovery_row:
        return 60
    # normalize 1-10 to 0-100; stress/soreness invert
    sleep = (recovery_row.get("sleep") or 6) * 10
    energy = (recovery_row.get("energy") or 6) * 10
    stress = (recovery_row.get("stress") or 5) * 10
    soreness = (recovery_row.get("soreness") or 5) * 10
    steps = min((recovery_row.get("steps") or 6000)/100, 100)
    score = 0.28*sleep + 0.28*energy + 0.18*(100-stress) + 0.18*(100-soreness) + 0.08*steps
    return int(max(0, min(100, round(score))))


def _compile_blocks(domain_key: str, exercises: list[dict], minutes: int, intensity: str, progression: str):
    """Convert simple exercise templates into timed blocks for the Session Player.
    Ensures: core block + breath/focus cue always present.
    """
    total_sec = max(15*60, int(minutes*60))
    # heuristics
    warmup_sec = int(total_sec*0.18)
    cooldown_sec = int(total_sec*0.12)
    core_sec = int(total_sec*0.12) if domain_key not in ("core",) else int(total_sec*0.18)
    main_sec = max(5*60, total_sec - warmup_sec - cooldown_sec - core_sec)

    # deload trims main volume further
    if progression == "Deload":
        main_sec = int(main_sec*0.75)
        drift = total_sec - (warmup_sec + cooldown_sec + core_sec + main_sec)
        cooldown_sec += max(0, drift)

    blocks = [
        {"label":"Warm-up · breath + mobility", "duration_sec": warmup_sec},
        {"label":"Core · stability + posture", "duration_sec": core_sec},
        {"label":"Main · " + domain_key.replace("_"," ").title(), "duration_sec": main_sec},
        {"label":"Cool-down · downshift", "duration_sec": cooldown_sec},
    ]
    return blocks

def _rotate_list(xs: list, n: int) -> list:
    if not xs: return xs
    n = n % len(xs)
    return xs[n:] + xs[:n]


def build_weekly_structure(frequency: int, minutes: int, domains: list[dict], intensity: str):
    # caps to avoid overwhelm
    high_cap = 1 if frequency <= 4 else 2
    if intensity == "Easy": high_cap = 0
    # baseline slots
    slots=[]
    # always include mobility/recovery at least once per week when possible
    pref_low=[d for d in domains if d["key"] in ("mobility","recovery","flexibility","longevity","taichi")]
    pref_strength=[d for d in domains if d["key"] in ("strength","hypertrophy","bodyweight","core","performance")]
    pref_high=[d for d in domains if d["key"] in ("hiit","martial_arts")]
    pref_endurance=[d for d in domains if d["key"]=="endurance"]
    # choose mix
    if frequency <= 3:
        # 1 strength, 1 low, 1 optional
        if pref_strength: slots.append(pref_strength[0]["key"])
        if pref_low: slots.append(pref_low[0]["key"])
        if frequency==3:
            slots.append((pref_endurance[0]["key"] if pref_endurance else (pref_strength[1]["key"] if len(pref_strength)>1 else pref_low[-1]["key"])))
    else:
        # ensure 2 strength-ish, 1 low, 1 core/perf, plus optional high/endurance
        if pref_strength: slots += [pref_strength[0]["key"], pref_strength[min(1,len(pref_strength)-1)]["key"]]
        if pref_low: slots.append(pref_low[0]["key"])
        if any(d["key"]=="core" for d in domains): slots.append("core")
        else: slots.append(pref_strength[0]["key"] if pref_strength else pref_low[0]["key"])
        # fill remaining
        high_used=0
        while len(slots) < frequency:
            candidate=None
            if pref_high and high_used < high_cap:
                candidate=pref_high[0]["key"]; high_used+=1
            elif pref_endurance:
                candidate=pref_endurance[0]["key"]
            else:
                candidate=pref_low[-1]["key"] if pref_low else domains[0]["key"]
            slots.append(candidate)
    # truncate
    return slots[:frequency]

def generate_4week_plan(profile: dict|None, intake: dict, recovery: dict|None, adherence_pct: int=60, settings: dict|None=None, templates: list[dict]|None=None, checkin_rating: str|None=None):
    injuries = (profile or {}).get("injuries","")
    level = ((profile or {}).get("training_level") or "beginner").lower()
    goal = ((profile or {}).get("goal") or "vitality").lower()
    equipment = ((profile or {}).get("equipment") or "minimal").lower()

    domains = allowed_domains(injuries)
    domain_keys=[d["key"] for d in domains]

    month_key = datetime.date.today().strftime("%Y-%m")
    # monthly variety: inject 2 domains if user selected none
    preferred = intake.get("preferred_styles") or []
    if not preferred:
        preferred = pick_monthly_variations(month_key, domain_keys, 2)

    readiness = compute_readiness(recovery)
    # settings-aware biases (founder mode)
    dial = ((settings or {}).get("intensity_dial") or "Standard").strip().lower()
    gov = ((settings or {}).get("recovery_governor") or "Balanced").strip().lower()
    dial_bias = {"low":-6,"standard":0,"high":6,"beast":10}.get(dial, 0)
    readiness = int(max(0, min(100, readiness + dial_bias)))
    # governor v2 (uses check-in + recovery flags)
    readiness = apply_recovery_governor(readiness, gov, recovery, (checkin_rating or "").strip().lower() or None)
    intensity = intensity_from_readiness(readiness, adherence_pct)(readiness, adherence_pct)

    # use intake first, then settings defaults
    freq = int(intake.get("frequency_per_week") or (settings or {}).get("plan_default_freq") or 3)
    mins = int(intake.get("minutes_per_session") or (settings or {}).get("plan_default_minutes") or 60)

    # One-shot modifiers (e.g., after a hard/easy week) — applied once then cleared by app.py
    try:
        nb = int((settings or {}).get("next_intensity_bias") or 0)
        if nb:
            readiness = int(max(0, min(100, readiness + nb)))
    except Exception:
        pass
    try:
        mb = int((settings or {}).get("next_minutes_bias") or 0)
        if mb:
            mins = int(max(20, min(75, mins + mb)))
    except Exception:
        pass


    # Programme engine v1: if trainer templates are provided (from enrolled programme), build plan from templates
    if templates:
        tmpl_plan = build_plan_from_templates(templates, freq, mins)
        if tmpl_plan:
            tmpl_plan["readiness_score"]=readiness
            tmpl_plan["intensity"]=intensity
            tmpl_plan["month_key"]=month_key
            tmpl_plan["preferred_styles"]=preferred
            return tmpl_plan, intensity, month_key

    # Build weekly template and rotate
    week_structure = build_weekly_structure(freq, mins, domains, intensity)

    # Add preferred domains gently (swap in)
    for p in preferred:
        if p in domain_keys and p not in week_structure:
            # replace a low slot if possible
            for i,k in enumerate(week_structure):
                if k in ("mobility","recovery","flexibility","longevity","taichi"):
                    week_structure[i]=p
                    break

    # Build weeks with progression and deload (W4)
    weeks=[]
    prev_ws=None
    for w in range(1,5):
        deload = (w==4)
        # rotate the weekly structure so Week 2/3 don't feel like copy/paste
        ws = _rotate_list(list(week_structure), (w-1))
        # deload week: bias toward low intensity domains
        if deload:
            low_pool=[k for k in ws if k in ("mobility","recovery","flexibility","longevity","taichi","core")]
            if not low_pool:
                low_pool=["mobility","recovery","core"]
            ws = [ (k if k not in ("hiit","martial_arts") else random.choice(low_pool)) for k in ws ]
        # avoid same domain in same slot as prior week where possible
        if prev_ws and len(ws)==len(prev_ws):
            for i in range(len(ws)):
                if ws[i]==prev_ws[i] and len(ws)>1:
                    ws = _rotate_list(ws, 1)
                    break
        prev_ws=list(ws)

        sessions=[]
        for idx,dk in enumerate(ws, start=1):
            ex = exercise_templates(dk, level)
            tag = "Normal"
            if deload:
                tag="Deload"
            elif w==2:
                tag="Volume+"
            elif w==3:
                tag="Intensity+"

            sess_minutes = mins if not deload else max(20, int(mins*0.75))
            blocks = _compile_blocks(dk, ex, sess_minutes, intensity, tag)

            sessions.append({
              "id": f"W{w}-S{idx}",
              "domain": dk,
              "title": f"{dk.replace('_',' ').title()} Session",
              "minutes": sess_minutes,
              "progression": tag,
              "equipment": equipment,
              "goal": goal,
              "exercises": ex,
              "blocks": blocks
            })
        weeks.append({"week":w,"deload":deload,"sessions":sessions})


    plan={
      "generated_at": datetime.datetime.utcnow().isoformat(),
      "month_key": month_key,
      "readiness_score": readiness,
      "intensity": intensity,
      "frequency_per_week": freq,
      "minutes_per_session": mins,
      "preferred_styles": preferred,
      "week_structure": week_structure,
      "weeks": weeks,
      "policy": {
        "standalone": True,
        "no_external_imports": True,
        "overwhelm_caps": {"high_intensity_cap_per_week": 1 if freq<=4 else 2}
      }
    }
    return plan, intensity, month_key

def qa_score(plan: dict|None, profile: dict|None, intake: dict|None):
    score=0
    gaps=[]
    if profile and profile.get("age") and profile.get("height_cm") and profile.get("weight_kg"):
        score+=15
    else:
        gaps.append("Profile incomplete (age/height/weight).")
    if intake and intake.get("frequency_per_week") and intake.get("minutes_per_session"):
        score+=15
    else:
        gaps.append("Intake incomplete (frequency/minutes).")
    if plan and plan.get("weeks"):
        score+=30
    else:
        gaps.append("No plan generated.")
    # domain coverage
    domains=set()
    for w in (plan or {}).get("weeks",[]):
        for s in w.get("sessions",[]):
            domains.add(s.get("domain"))
    if len(domains) >= 5:
        score+=20
    else:
        gaps.append("Low domain diversity. Add preferences or increase frequency.")
    # overwhelm guard: ensure at least one low-intensity domain per week
    low=set(["mobility","recovery","flexibility","longevity","taichi"])
    if any(d in low for d in domains):
        score+=10
    else:
        gaps.append("No recovery/mobility session included (overwhelm risk).")
    # exercises embedded
    if plan and all(s.get("exercises") for w in plan.get("weeks",[]) for s in w.get("sessions",[])):
        score+=10
    else:
        gaps.append("Some sessions missing exercise detail.")
    return min(100, score), gaps, sorted(domains)
