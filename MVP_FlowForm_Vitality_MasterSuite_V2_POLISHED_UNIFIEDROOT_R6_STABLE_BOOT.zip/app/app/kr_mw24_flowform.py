
import os, json, time, uuid, datetime, zipfile, io
from pathlib import Path

def _now_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat()+"Z"

def _exports_dir(app_root: str):
    p = Path(app_root) / "exports"
    p.mkdir(parents=True, exist_ok=True)
    return p

def _logs_dir(app_root: str):
    p = Path(app_root) / "logs"
    p.mkdir(parents=True, exist_ok=True)
    return p

def _write_json(path: Path, obj):
    path.write_text(json.dumps(obj, indent=2), encoding="utf-8")

def _append_log(path: Path, line: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(line.rstrip()+"\n")

def _make_zip(zip_path: Path, file_paths):
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for fp in file_paths:
            fp = Path(fp)
            if fp.exists():
                z.write(fp, arcname=fp.name)

def generate_session(duration_min:int=45, focus:str="Vitality", level:str="All", style:str="FlowForm"):
    duration_min = int(max(30, min(75, duration_min)))
    # simple block structure: warmup, main, cooldown, reflection
    warm = max(5, duration_min//6)
    cool = max(5, duration_min//6)
    main = duration_min - warm - cool - 5
    refl = 5
    blocks = [
        {"name":"Arrival + Breath primer", "mins":warm, "tags":["breath","mobility"]},
        {"name":f"Main practice ({focus})", "mins":main, "tags":[focus.lower(),"strength" if "Strength" in focus else "flow"]},
        {"name":"Cooldown + reset", "mins":cool, "tags":["stretch","downregulate"]},
        {"name":"Reflection + notes", "mins":refl, "tags":["journal","habit"]},
    ]
    return {
        "generated_at": _now_iso(),
        "duration_mins": duration_min,
        "focus": focus,
        "level": level,
        "style": style,
        "blocks": blocks,
        "export_contract": {"json":"exports/mw24_last_session.json", "md":"exports/mw24_last_session.md"}
    }

def _render_md(sess:dict)->str:
    lines=[f"# FlowForm Session — {sess['focus']} ({sess['duration_mins']} min)",
           f"- Generated: {sess['generated_at']}",
           f"- Level: {sess['level']}",
           "",
           "## Blocks"]
    for i,b in enumerate(sess["blocks"], start=1):
        lines.append(f"{i}. **{b['name']}** — {b['mins']} min  _(tags: {', '.join(b['tags'])})_")
    lines.append("")
    lines.append("## Notes")
    lines.append("- What felt easy?")
    lines.append("- What felt hard?")
    lines.append("- One tweak for next time.")
    return "\n".join(lines)

def run_mw24(app_root:str, duration_min:int=45, focus:str="Vitality", level:str="All"):
    job_id = "MW24-" + uuid.uuid4().hex[:10]
    exp = _exports_dir(app_root)
    logs = _logs_dir(app_root)
    logp = logs / "mw24_audit.log"
    sess = generate_session(duration_min, focus, level)
    sess["job_id"]=job_id
    sess["artifacts"]=[]
    json_path = exp / "mw24_last_session.json"
    md_path = exp / "mw24_last_session.md"
    _write_json(json_path, sess)
    md_path.write_text(_render_md(sess), encoding="utf-8")
    sess["artifacts"]=[str(json_path), str(md_path)]
    zip_path = exp / f"{job_id}_FlowForm_SessionPack.zip"
    _make_zip(zip_path, [json_path, md_path])
    sess["zip"]=str(zip_path)
    _append_log(logp, f"{_now_iso()} {job_id} focus={focus} duration={sess['duration_mins']} mins zip={zip_path.name}")
    # update summary
    _write_json(exp / "mw24_last_summary.json", sess)
    return sess

def register_flask(app, app_root:str):
    from flask import request, jsonify, render_template_string
    MW24_HTML = """
    <html><head><title>FlowForm MW2.4</title></head>
    <body style="font-family:Arial;max-width:860px;margin:24px;">
      <h1>FlowForm MegaWave 2.4 — Session Generator</h1>
      <p>One-click session pack generator (30–75 mins). Writes to <code>exports/</code>.</p>
      <form method="post" action="/api/mw24/run">
        <label>Duration (mins):</label>
        <input name="duration_min" value="45" />
        <label>Focus:</label>
        <input name="focus" value="Vitality" />
        <label>Level:</label>
        <input name="level" value="All" />
        <button type="submit">Run MW24</button>
      </form>
      <hr/>
      <p><a href="/api/schema">View API Schema</a></p>
      <p><a href="/api/selfcheck">Selfcheck</a> | <a href="/health">Health</a></p>
    </body></html>
    """
    @app.get("/mw24")
    def mw24_page():
        return render_template_string(MW24_HTML)

    @app.post("/api/mw24/run")
    def mw24_run():
        dur = request.form.get("duration_min") or request.json.get("duration_min",45) if request.is_json else 45
        focus = request.form.get("focus") or (request.json.get("focus","Vitality") if request.is_json else "Vitality")
        level = request.form.get("level") or (request.json.get("level","All") if request.is_json else "All")
        res = run_mw24(app_root, int(dur), str(focus), str(level))
        return jsonify(res)

def register_fastapi(app, app_root:str):
    from fastapi import Body
    from fastapi.responses import HTMLResponse
    @app.get("/mw24", response_class=HTMLResponse)
    def mw24_page():
        return HTMLResponse("<h1>FlowForm MegaWave 2.4</h1><p>POST /api/mw24/run</p>")
    @app.post("/api/mw24/run")
    def mw24_run(payload: dict = Body(default={})):
        dur = payload.get("duration_min",45)
        focus = payload.get("focus","Vitality")
        level = payload.get("level","All")
        return run_mw24(app_root, int(dur), str(focus), str(level))
