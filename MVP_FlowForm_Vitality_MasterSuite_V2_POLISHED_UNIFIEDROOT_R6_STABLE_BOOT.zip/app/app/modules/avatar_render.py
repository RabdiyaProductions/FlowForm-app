
import os, shutil, tempfile, subprocess, json, datetime
from pathlib import Path

try:
    import imageio.v2 as imageio
    import numpy as np
except Exception:
    imageio = None
    np = None

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = BASE_DIR / "uploads"

def now_iso():
    return datetime.datetime.utcnow().isoformat()

def detect_blender() -> str | None:
    """
    Returns a path to blender if available.
    Priority:
      1) BLENDER_PATH env
      2) blender on PATH
    """
    p = os.environ.get("BLENDER_PATH")
    if p and Path(p).exists():
        return str(Path(p))
    which = shutil.which("blender")
    return which

def blender_template_path() -> str | None:
    p = DATA_DIR / "blender" / "template.blend"
    if p.exists():
        return str(p)
    return None

def ensure_dirs():
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

def render_placeholder_loop(title: str="FlowForm Avatar", seconds: float=3.0, fps: int=24, w: int=720, h: int=720) -> str:
    """
    Generates a clean MP4 loop placeholder using pure-python frames.
    This is NOT a true 3D render; it's a production-safe placeholder that can be replaced later.
    """
    ensure_dirs()
    if imageio is None or np is None:
        raise RuntimeError("imageio/numpy not available to generate placeholder loop.")
    frames = int(max(1, seconds * fps))
    t = np.linspace(0, 2*np.pi, frames)
    out_path = UPLOAD_DIR / f"avatar_loop_{int(datetime.datetime.utcnow().timestamp())}.mp4"
    writer = imageio.get_writer(str(out_path), fps=fps, codec="libx264", quality=8)
    try:
        for i in range(frames):
            # background gradient + orbiting ring
            img = np.zeros((h,w,3), dtype=np.uint8)
            # gradient
            gx = (np.linspace(0, 1, w)[None, :] * 255).astype(np.uint8)
            img[...,0] = gx
            img[...,1] = np.flip(gx, axis=1)
            img[...,2] = (128 + 127*np.sin(t[i])).astype(np.uint8)
            # ring
            cx, cy = w//2, h//2
            rr = int(min(w,h)*0.32)
            x = np.arange(w)[None, :]
            y = np.arange(h)[:, None]
            ang = t[i]
            ox = int(cx + rr*0.55*np.cos(ang))
            oy = int(cy + rr*0.55*np.sin(ang))
            dist = (x-ox)**2 + (y-oy)**2
            ring = (dist < (rr*0.22)**2) & (dist > (rr*0.17)**2)
            img[ring] = [240,240,240]
            # subtle center glow
            distc = (x-cx)**2 + (y-cy)**2
            glow = distc < (rr*0.18)**2
            img[glow] = np.clip(img[glow] + 40, 0, 255)
            writer.append_data(img)
    finally:
        writer.close()
    return str(out_path)

def render_with_blender(job_spec: dict) -> str:
    """
    Attempts to render an MP4 loop via Blender headless.
    Requires:
      - Blender installed (BLENDER_PATH or blender on PATH)
      - template.blend present at app/data/blender/template.blend
    """
    ensure_dirs()
    blender = detect_blender()
    tpl = blender_template_path()
    if not blender:
        raise RuntimeError("Blender not detected. Set BLENDER_PATH or install Blender in PATH.")
    if not tpl:
        raise RuntimeError("Blender template missing. Place template.blend at app/data/blender/template.blend")

    tmp = Path(tempfile.mkdtemp(prefix="flowform_blender_"))
    try:
        spec_path = tmp / "job.json"
        spec_path.write_text(json.dumps(job_spec, indent=2), encoding="utf-8")
        script_path = tmp / "render.py"
        script_path.write_text(_BLENDER_RENDER_SCRIPT, encoding="utf-8")

        # Output path (mp4)
        out_path = UPLOAD_DIR / f"avatar3d_{int(datetime.datetime.utcnow().timestamp())}.mp4"
        # blender args: -- job.json output.mp4
        cmd = [blender, "-b", tpl, "-P", str(script_path), "--", str(spec_path), str(out_path)]
        subprocess.check_call(cmd)
        if not out_path.exists():
            raise RuntimeError("Blender render did not produce output.")
        return str(out_path)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

# Minimal blender python script (exec'd inside Blender)
_BLENDER_RENDER_SCRIPT = r"""
import bpy, sys, json, os

argv = sys.argv
if "--" in argv:
    argv = argv[argv.index("--")+1:]
else:
    argv = []
spec_path = argv[0] if len(argv)>0 else None
out_path = argv[1] if len(argv)>1 else None

spec = {}
if spec_path and os.path.exists(spec_path):
    with open(spec_path, "r", encoding="utf-8") as f:
        spec = json.load(f)

# Basic expectations: template.blend already has camera/light/rig or placeholder scene.
# Users can customize template.blend to define the actual 3D avatar and animation.
scene = bpy.context.scene
scene.render.filepath = out_path
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'
scene.render.ffmpeg.codec = 'H264'
scene.render.ffmpeg.constant_rate_factor = 'HIGH'
scene.render.ffmpeg.ffmpeg_preset = 'GOOD'
scene.render.resolution_x = int(spec.get("width", 720))
scene.render.resolution_y = int(spec.get("height", 720))
scene.render.fps = int(spec.get("fps", 24))

# Animation frames
seconds = float(spec.get("seconds", 3.0))
scene.frame_start = 1
scene.frame_end = max(1, int(seconds*scene.render.fps))

# Render animation
bpy.ops.render.render(animation=True)
"""
