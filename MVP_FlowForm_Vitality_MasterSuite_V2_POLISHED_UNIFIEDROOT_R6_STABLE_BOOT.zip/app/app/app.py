"""
FlowForm Vitality Master Suite (MVP) — Flask app

This is a deliberately small, robust baseline:
- Boots every time
- Creates its own SQLite db
- Provides stable routes you can extend in Canva/Codex
"""
from __future__ import annotations

import json
from pathlib import Path
from flask import Flask, request, redirect, url_for, render_template_string, jsonify

import db

BASE_HTML = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>{{ title }}</title>
  <style>
    body{font-family:system-ui,Segoe UI,Arial,sans-serif;margin:24px;background:#0b1220;color:#e8eefc}
    a{color:#8ab4ff;text-decoration:none}
    .card{background:#121b30;border:1px solid #22304f;border-radius:14px;padding:16px;margin:12px 0}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
    .btn{display:inline-block;padding:10px 12px;border-radius:10px;background:#1d2a48;border:1px solid #2a3a61}
    input,select,textarea{width:100%;padding:10px;border-radius:10px;border:1px solid #2a3a61;background:#0b1220;color:#e8eefc}
    label{font-size:12px;color:#b8c7ef}
    h1{margin:0 0 6px 0}
    .muted{color:#b8c7ef}
    table{width:100%;border-collapse:collapse}
    th,td{padding:8px;border-bottom:1px solid #22304f;text-align:left;font-size:14px}
    th{color:#b8c7ef;font-weight:600}
  </style>
</head>
<body>
  <div class="card">
    <div class="muted">FlowForm</div>
    <h1>{{ title }}</h1>
    <div class="muted">{{ subtitle }}</div>
    <div style="margin-top:10px">
      <a class="btn" href="{{ url_for('home') }}">Dashboard</a>
      <a class="btn" href="{{ url_for('log_session') }}">Log Session</a>
      <a class="btn" href="{{ url_for('metrics') }}">Metrics</a>
      <a class="btn" href="{{ url_for('notes') }}">Notes</a>
      <a class="btn" href="{{ url_for('health') }}">Health</a>
    </div>
  </div>

  {{ body|safe }}

  <div class="muted" style="margin-top:26px">
    Local-only MVP • Data stored in SQLite • Build to “true ready” next 🧱
  </div>
</body>
</html>
"""

def create_app() -> Flask:
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "dev-only-change-me"
    # Optional override via env in later phases
    app.config.setdefault("DB_PATH", str(Path(app.root_path).parent / "data" / "flowform_vitality.db"))

    @app.before_request
    def _ensure_db():
        # Keep init cheap/idempotent
        db.init_db()

    app.teardown_appcontext(db.close_db)

    @app.get("/health")
    def health():
        return jsonify(ok=True)

    @app.get("/")
    def home():
        conn = db.get_db()
        sessions = conn.execute(
            "SELECT ts, session_type, duration_min, intensity, notes FROM session_log ORDER BY id DESC LIMIT 10"
        ).fetchall()

        body = render_template_string("""
        <div class="grid">
          <div class="card">
            <div class="muted">Quick start</div>
            <p>Log a session, track metrics, and keep notes. This is the stable core we’ll extend.</p>
            <p><a class="btn" href="{{ url_for('log_session') }}">Log a session</a></p>
          </div>
          <div class="card">
            <div class="muted">Today</div>
            <p>When you’re ready, we’ll add schedule templates (30–75 min) and session builder.</p>
          </div>
        </div>

        <div class="card">
          <div class="muted">Recent sessions</div>
          {% if sessions %}
          <table>
            <tr><th>Time</th><th>Type</th><th>Minutes</th><th>Intensity</th><th>Notes</th></tr>
            {% for s in sessions %}
              <tr>
                <td>{{ s["ts"] }}</td>
                <td>{{ s["session_type"] }}</td>
                <td>{{ s["duration_min"] }}</td>
                <td>{{ s["intensity"] }}</td>
                <td>{{ s["notes"] }}</td>
              </tr>
            {% endfor %}
          </table>
          {% else %}
            <p>No sessions yet.</p>
          {% endif %}
        </div>
        """, sessions=sessions)

        return render_template_string(BASE_HTML, title="Vitality Master Suite", subtitle="Internal MVP", body=body)

    @app.route("/log-session", methods=["GET", "POST"])
    def log_session():
        if request.method == "POST":
            session_type = request.form.get("session_type", "Vitality")
            duration_min = int(request.form.get("duration_min", "45") or 45)
            intensity = int(request.form.get("intensity", "5") or 5)
            notes = request.form.get("notes", "")
            conn = db.get_db()
            conn.execute(
                "INSERT INTO session_log(session_type, duration_min, intensity, notes) VALUES(?,?,?,?)",
                (session_type, duration_min, intensity, notes),
            )
            conn.commit()
            return redirect(url_for("home"))

        body = """
        <div class="card">
          <form method="post">
            <div class="grid">
              <div>
                <label>Session type</label>
                <select name="session_type">
                  <option>Vitality</option>
                  <option>Mobility</option>
                  <option>Strength</option>
                  <option>Recovery</option>
                  <option>Cardio</option>
                  <option>Breathwork</option>
                </select>
              </div>
              <div>
                <label>Duration (minutes)</label>
                <input name="duration_min" value="45" />
              </div>
              <div>
                <label>Intensity (1–10)</label>
                <input name="intensity" value="5" />
              </div>
            </div>
            <div style="margin-top:12px">
              <label>Notes</label>
              <textarea name="notes" rows="4" placeholder="How did it feel? Any tweaks for next time?"></textarea>
            </div>
            <div style="margin-top:12px">
              <button class="btn" type="submit">Save</button>
            </div>
          </form>
        </div>
        """
        return render_template_string(BASE_HTML, title="Log session", subtitle="Track what you do", body=body)

    @app.route("/metrics", methods=["GET", "POST"])
    def metrics():
        conn = db.get_db()
        if request.method == "POST":
            metric = request.form.get("metric", "weight")
            value = float(request.form.get("value", "0") or 0)
            unit = request.form.get("unit", "")
            conn.execute("INSERT INTO metrics(metric, value, unit) VALUES(?,?,?)", (metric, value, unit))
            conn.commit()
            return redirect(url_for("metrics"))

        rows = conn.execute("SELECT ts, metric, value, unit FROM metrics ORDER BY id DESC LIMIT 20").fetchall()
        body = render_template_string("""
        <div class="card">
          <form method="post" class="grid">
            <div>
              <label>Metric</label>
              <select name="metric">
                <option value="weight">Weight</option>
                <option value="sleep">Sleep</option>
                <option value="steps">Steps</option>
                <option value="resting_hr">Resting HR</option>
                <option value="mood">Mood</option>
              </select>
            </div>
            <div>
              <label>Value</label>
              <input name="value" placeholder="e.g. 78.4" />
            </div>
            <div>
              <label>Unit</label>
              <input name="unit" placeholder="kg / hours / bpm" />
            </div>
            <div style="align-self:end">
              <button class="btn" type="submit">Add</button>
            </div>
          </form>
        </div>

        <div class="card">
          <div class="muted">Recent metrics</div>
          {% if rows %}
          <table>
            <tr><th>Time</th><th>Metric</th><th>Value</th><th>Unit</th></tr>
            {% for r in rows %}
              <tr><td>{{ r["ts"] }}</td><td>{{ r["metric"] }}</td><td>{{ r["value"] }}</td><td>{{ r["unit"] }}</td></tr>
            {% endfor %}
          </table>
          {% else %}
            <p>No metrics yet.</p>
          {% endif %}
        </div>
        """, rows=rows)
        return render_template_string(BASE_HTML, title="Metrics", subtitle="Track inputs & outcomes", body=body)

    @app.route("/notes", methods=["GET", "POST"])
    def notes():
        conn = db.get_db()
        if request.method == "POST":
            title = request.form.get("title", "").strip() or "Note"
            body = request.form.get("body", "").strip()
            conn.execute("INSERT INTO notes(title, body) VALUES(?,?)", (title, body))
            conn.commit()
            return redirect(url_for("notes"))

        rows = conn.execute("SELECT ts, title, body FROM notes ORDER BY id DESC LIMIT 20").fetchall()
        body = render_template_string("""
        <div class="card">
          <form method="post">
            <div class="grid">
              <div>
                <label>Title</label>
                <input name="title" placeholder="e.g. Weekly plan" />
              </div>
            </div>
            <div style="margin-top:12px">
              <label>Body</label>
              <textarea name="body" rows="4" placeholder="Write anything…"></textarea>
            </div>
            <div style="margin-top:12px">
              <button class="btn" type="submit">Save</button>
            </div>
          </form>
        </div>

        <div class="card">
          <div class="muted">Recent notes</div>
          {% if rows %}
            {% for r in rows %}
              <div class="card" style="background:#0b1220">
                <div class="muted">{{ r["ts"] }}</div>
                <div style="font-weight:650">{{ r["title"] }}</div>
                <div style="white-space:pre-wrap">{{ r["body"] }}</div>
              </div>
            {% endfor %}
          {% else %}
            <p>No notes yet.</p>
          {% endif %}
        </div>
        """, rows=rows)
        return render_template_string(BASE_HTML, title="Notes", subtitle="Capture insights", body=body)

    return app
