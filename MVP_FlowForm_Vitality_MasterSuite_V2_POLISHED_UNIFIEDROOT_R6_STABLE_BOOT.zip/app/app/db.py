"""
FlowForm Vitality — lightweight SQLite layer (MVP)

Design goals:
- Zero external deps (stdlib only)
- Safe connection lifecycle (Flask g)
- Idempotent init
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Optional

from flask import g, current_app

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS programme_pack (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL,
  name TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_programme_pack_source_name
ON programme_pack(source, name);

CREATE TABLE IF NOT EXISTS session_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL DEFAULT (datetime('now')),
  session_type TEXT NOT NULL,
  duration_min INTEGER NOT NULL,
  intensity INTEGER NOT NULL DEFAULT 5,
  notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS metrics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL DEFAULT (datetime('now')),
  metric TEXT NOT NULL,
  value REAL NOT NULL,
  unit TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL DEFAULT (datetime('now')),
  title TEXT NOT NULL,
  body TEXT NOT NULL
);
"""

def _db_path() -> Path:
    # Prefer instance folder if available; otherwise fall back to app/data
    cfg = current_app.config.get("DB_PATH")
    if cfg:
        p = Path(cfg)
    else:
        p = Path(current_app.root_path).parent / "data" / "flowform_vitality.db"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p

def get_db() -> sqlite3.Connection:
    conn: Optional[sqlite3.Connection] = g.get("db_conn")
    if conn is None:
        conn = sqlite3.connect(_db_path(), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        g.db_conn = conn
    return conn

def close_db(e=None) -> None:
    conn = g.pop("db_conn", None)
    if conn is not None:
        conn.close()

def init_db() -> None:
    conn = get_db()
    conn.executescript(SCHEMA_SQL)
    conn.commit()
