FlowForm Vitality - Avatar Render Pipeline (Founder)

To enable TRUE 3D avatar MP4 loop rendering:
1) Install Blender (https://www.blender.org/download/)
2) Set environment variable BLENDER_PATH to the blender executable path
   Example (Windows):
     setx BLENDER_PATH "C:\Program Files\Blender Foundation\Blender 4.2\blender.exe"
3) Place your template Blender file here as:
     app/data/blender/template.blend

The template should include your 3D avatar, rig, lights, camera, and an animation timeline.
The app will render frames 1..(seconds*fps) and export an MP4 (H.264).

If Blender is not installed, the app will generate high-quality MP4 placeholders automatically.
