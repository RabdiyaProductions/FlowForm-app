import sys, json, urllib.request, urllib.error, os

def get_port():
    try:
        with open("PORT.txt","r",encoding="utf-8") as f:
            return int(f.read().strip())
    except Exception:
        return int(os.environ.get("PORT","5800"))

def fetch(url):
    req=urllib.request.Request(url, headers={"User-Agent":"KRSTD-smoketest"})
    with urllib.request.urlopen(req, timeout=5) as r:
        return r.status, r.read().decode("utf-8", errors="ignore")

def main():
    port=get_port()
    base=f"http://127.0.0.1:{port}"
    checks=[("/health",200),("/api/selfcheck",200)]
    for path,code in checks:
        try:
            status,_=fetch(base+path)
            if status!=code:
                print(f"FAIL {path} status={status} expected={code}")
                return 1
        except Exception as e:
            print(f"FAIL {path} error={e}")
            return 1
    print("PASS")
    return 0

if __name__=="__main__":
    sys.exit(main())
