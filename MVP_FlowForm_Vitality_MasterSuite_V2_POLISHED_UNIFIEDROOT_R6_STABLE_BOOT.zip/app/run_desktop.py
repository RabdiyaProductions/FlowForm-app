import json
import webbrowser
from pathlib import Path
from subprocess import Popen
import sys


def main():
    here = Path(__file__).resolve().parent
    meta_path = here / "meta.json"
    port = 5404
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            port = int(meta.get("port", port))
        except Exception:
            pass

    # Start the server in a background console
    if sys.platform.startswith("win"):
        # CREATE_NEW_CONSOLE = 0x00000010
        Popen(["python", "run_server.py"], creationflags=0x00000010)
    else:
        Popen(["python", "run_server.py"])

    url = f"http://127.0.0.1:{port}/"
    webbrowser.open(url)


if __name__ == "__main__":
    main()
