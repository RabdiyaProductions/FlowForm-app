import os, json, datetime

class LLMError(Exception):
    pass

def _mask(s: str) -> str:
    if not s: return ""
    if len(s) <= 8: return "*"*len(s)
    return s[:3] + "*"*(len(s)-7) + s[-4:]

def provider_status():
    """Return dict with provider availability and config (no secrets)."""
    api_key = os.environ.get("FLOWFORM_OPENAI_API_KEY") or os.environ.get("OPENAI_API_KEY")
    return {
        "openai_sdk_installed": _has_openai(),
        "api_key_present": bool(api_key),
        "api_key_hint": _mask(api_key) if api_key else "",
        "default_model": os.environ.get("FLOWFORM_OPENAI_MODEL","gpt-4o-mini"),
    }

def _has_openai():
    try:
        import openai  # noqa
        return True
    except Exception:
        return False

def chat(messages, model=None, temperature=0.2, max_tokens=800):
    """Simple chat wrapper. Expects messages=[{role,content},...]"""
    api_key = os.environ.get("FLOWFORM_OPENAI_API_KEY") or os.environ.get("OPENAI_API_KEY")
    model = model or os.environ.get("FLOWFORM_OPENAI_MODEL","gpt-4o-mini")

    if not _has_openai():
        raise LLMError("OpenAI SDK not installed. Run setup again to install requirements, or add openai to requirements.txt.")
    if not api_key:
        raise LLMError("Missing API key. Set FLOWFORM_OPENAI_API_KEY or OPENAI_API_KEY in your environment.")

    from openai import OpenAI
    client = OpenAI(api_key=api_key)

    resp = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=float(temperature),
        max_tokens=int(max_tokens),
    )
    msg = resp.choices[0].message
    return {
        "model": model,
        "content": msg.content or "",
        "usage": getattr(resp, "usage", None).model_dump() if getattr(resp,"usage",None) else None,
        "ts": datetime.datetime.utcnow().isoformat()
    }
