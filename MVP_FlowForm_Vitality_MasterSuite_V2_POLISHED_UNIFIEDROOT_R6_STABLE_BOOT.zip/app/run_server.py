import json
from pathlib import Path

from werkzeug.serving import run_simple

from boot_app import create_app


def main():
    here = Path(__file__).resolve().parent
    meta_path = here / "meta.json"
    port = 5404
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            port = int(meta.get("port", port))
        except Exception:
            pass

    app = create_app()
    run_simple("127.0.0.1", port, app, use_reloader=False, use_debugger=True)


if __name__ == "__main__":
    main()
