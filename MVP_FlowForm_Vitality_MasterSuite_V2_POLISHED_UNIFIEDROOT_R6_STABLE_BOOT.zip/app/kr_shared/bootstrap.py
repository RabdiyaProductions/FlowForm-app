import os, json, time, sqlite3, zipfile
from pathlib import Path
from datetime import datetime

def _now():
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

def ensure_dirs(base_dir: Path):
    (base_dir / "logs").mkdir(exist_ok=True, parents=True)
    (base_dir / "exports").mkdir(exist_ok=True, parents=True)
    (base_dir / "data").mkdir(exist_ok=True, parents=True)

def _log_jsonl(log_path: Path, obj: dict):
    obj = dict(obj)
    obj.setdefault("ts", _now())
    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

def db_path(base_dir: Path) -> Path:
    return base_dir / "data" / "app.sqlite3"

def db_connect(base_dir: Path):
    p = db_path(base_dir)
    con = sqlite3.connect(str(p))
    con.execute("PRAGMA journal_mode=WAL;")
    return con

def migrate(base_dir: Path):
    ensure_dirs(base_dir)
    con = db_connect(base_dir)
    cur = con.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS migrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            applied_at TEXT NOT NULL
        );
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            app TEXT NOT NULL,
            action TEXT NOT NULL,
            detail_json TEXT NOT NULL
        );
    """)
    con.commit()
    con.close()

def audit(base_dir: Path, app_name: str, action: str, detail: dict):
    migrate(base_dir)
    con = db_connect(base_dir)
    con.execute(
        "INSERT INTO audit_log(ts, app, action, detail_json) VALUES (?,?,?,?)",
        (_now(), app_name, action, json.dumps(detail, ensure_ascii=False))
    )
    con.commit()
    con.close()
    _log_jsonl(base_dir / "logs" / "app.jsonl", {
        "app": app_name, "event": "audit", "action": action, "detail": detail
    })

def build_schema(app_name: str) -> dict:
    return {
        "app": app_name,
        "version": os.environ.get("APP_VERSION", "unknown"),
        "capabilities": {"db": "sqlite3", "audit_log": True, "diagnostics": True}
    }

def register_flask(app, app_name: str, base_dir: str = "."):
    base_dir = Path(base_dir).resolve()
    migrate(base_dir)

    @app.get("/api/schema")
    def _schema():
        return build_schema(app_name)

    @app.get("/api/selfcheck")
    def _selfcheck():
        try:
            con = db_connect(base_dir); con.execute("SELECT 1"); con.close()
            audit(base_dir, app_name, "selfcheck", {"status":"ok"})
            return {"ok": True, "ts": _now(), "app": app_name}
        except Exception as e:
            _log_jsonl(base_dir/"logs"/"app.jsonl", {"app":app_name,"event":"selfcheck_fail","error":str(e)})
            return {"ok": False, "error": str(e)}, 500

    @app.get("/api/diagnostics")
    def _diagnostics():
        ensure_dirs(base_dir)
        out = base_dir / "exports" / f"diagnostics_{app_name}_{int(time.time())}.zip"
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
            for rel in ["logs/app.jsonl", "config/app.manifest.json", "PORT.txt"]:
                p = base_dir / rel
                if p.exists(): z.write(p, arcname=rel)
            for p in (base_dir/"exports").glob("*summary*.json"):
                z.write(p, arcname=f"exports/{p.name}")
            dbp = db_path(base_dir)
            if dbp.exists(): z.write(dbp, arcname="data/app.sqlite3")
        audit(base_dir, app_name, "diagnostics_export", {"zip": out.name})
        return {"ok": True, "zip": out.name}

    return app
