"""BOOTSAFE wrapper for FlowForm Vitality MasterSuite.

Loads the inner app/app.py module directly and exposes create_app()
for the standard empire boot runners.
"""
from __future__ import annotations

import sys
from importlib.machinery import SourceFileLoader
from pathlib import Path
import sys

# Ensure inner app folder is importable (so app.py can import db.py reliably)
here = Path(__file__).resolve().parent
sys.path.insert(0, str(here / 'app'))


def create_app():
    here = Path(__file__).resolve().parent
    # Ensure inner app directory and bundle app root are importable
    inner_dir = (here / 'app').resolve()
    if str(inner_dir) not in sys.path:
        sys.path.insert(0, str(inner_dir))
    if str(here) not in sys.path:
        sys.path.insert(0, str(here))
    inner_path = here / "app" / "app.py"

    module_name = "flowform_vitality_inner_app"
    module = SourceFileLoader(module_name, str(inner_path)).load_module()

    if not hasattr(module, "create_app"):
        raise RuntimeError("FlowForm Vitality inner app has no create_app()")

    return module.create_app()