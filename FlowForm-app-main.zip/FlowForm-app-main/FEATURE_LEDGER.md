# FEATURE_LEDGER

## Founder-critical flows (implemented)

### 1) Create plan flow
#### UI: `GET /plan/wizard`
Fields:
- goal (`strength`, `fat_loss`, `mobility`, `stress`, `hybrid`)
- days/week (`2`–`6`)
- minutes/session (`30`–`75`)
- discipline preference rank 1–5
- injury flags, equipment, constraints

#### API: `POST /api/plan/create`
Behavior:
- validates/clamps inputs
- computes discipline ordering + progressive 4-week structure
- persists `profile`, `plan`, `plan_day`

#### UI: `GET /plan/current`
Behavior:
- calendar-style week/day list
- Today marker
- completion badge when a `session_completion` exists
- CTA **Start today’s session**
- CTA **Regenerate next week** (preserves completed sessions)

Exact click steps:
1. Open `/plan/wizard`.
2. Fill wizard fields and click **Create 4-week plan**.
3. App redirects to `/plan/current` and shows persisted plan.

---

### 2) Do session flow
#### UI: `GET /session/start/<plan_day_id>`
Behavior:
- ordered blocks loaded from `session_template.json_blocks`
- controls: **Start / Pause / Next / Back / Finish**
- timer per block (countdown)

#### Finish API: `POST /api/session/finish`
Payload:
- `plan_day_id`
- `rpe` (1–10)
- `notes`
- `minutes_done`

Persistence:
- inserts `session_completion`
- writes `audit_log` event
- returns redirect to `/session/summary/<completion_id>`

#### UI: `GET /session/summary/<completion_id>`
Behavior:
- shows completion fields (RPE, notes, minutes, timestamp)
- link back to `/plan/current`

Exact click steps:
1. Open `/plan/current`.
2. Click **Start today’s session**.
3. In player, use Start/Pause/Next/Back as needed.
4. Click **Finish**, enter RPE + notes + minutes.
5. Click **Save completion**.
6. Land on `/session/summary/<completion_id>`.
7. Return to `/plan/current` and confirm row shows **Completed**.

---

## Supporting endpoints still present
- `/health`, `/api/health`
- `/diagnostics` (HTML), `/api/diagnostics` (JSON)
- `/api/spec`
- timeline/critic/import/export stubs


---

### 3) Daily recovery loop
#### UI: `GET /recovery`
Behavior:
- daily check-in form (sleep/stress/soreness/mood/notes)
- list of last 14 days
- explicit safety disclaimer: not medical advice

#### API: `POST /api/recovery/checkin`
Behavior:
- upserts check-in for the day
- computes explainable readiness score from sleep/stress/soreness/mood
- persists readiness explanation in notes and emits readiness score in API response

#### Integration in `GET /plan/current`
Behavior:
- readiness badge shown from latest check-in
- if readiness is low, show non-destructive lighter-template suggestion for today
- plan is never auto-overwritten by readiness suggestion

Exact click steps:
1. Open `/recovery`.
2. Submit daily check-in.
3. Open `/plan/current`.
4. Verify readiness badge and low-readiness suggestion (when applicable).
## Founder-critical plan flow (implemented)

### UI Route: `/plan/wizard` (GET)
Purpose: collect founder planning inputs and submit plan creation.

Fields implemented:
- goal (`strength`, `fat_loss`, `mobility`, `stress`, `hybrid`)
- days/week (`2` to `6`)
- minutes/session (`30` to `75`)
- discipline preferences (rank 1–5)
- constraints (injury flags, equipment, freeform constraints)

Exact click steps:
1. Open `/plan/wizard`.
2. Fill the required fields.
3. Click **Create 4-week plan**.
4. App posts to `POST /api/plan/create` and redirects to `/plan/current`.

### API Route: `/api/plan/create` (POST)
Purpose: generate and persist a 4-week plan.

Behavior implemented:
- Validates/clamps days/week and minutes/session ranges.
- Resolves ordered disciplines from ranked inputs + goal defaults.
- Upserts founder profile preferences.
- Archives existing active plan for same founder.
- Creates new active 4-week plan.
- Generates progressive week/day structure and inserts `plan_day` rows.
- Writes `audit_log` event `plan_created`.

Persistence targets:
- `profile`
- `plan`
- `plan_day`
- `audit_log`

### UI Route: `/plan/current` (GET)
Purpose: display persisted current plan with calendar-style week/day rows.

Implemented UI elements:
- Week cards with day rows, discipline, and duration.
- Today selector (`Week X, Day Y`) computed from plan start date.
- CTA: **Start today's session**.
- CTA: **Regenerate next week** (`POST /api/plan/regenerate-next-week`).

Regeneration behavior:
- Rebuilds next-week rows.
- Does not delete rows that already have `session_completion` records.

## Supporting schema (used by flow)
- `users`
- `profile`
- `plan`
- `plan_day`
- `session_template`
- `session_completion`
- `recovery_checkin`
- `audit_log`

All tables are created via safe migration rules (`CREATE TABLE IF NOT EXISTS` + checked `ALTER`).

## Health and diagnostics for this flow
- `/api/health` includes:
  - `db_ok`
  - `template_count`
- `/diagnostics` includes DB integrity checks and required route coverage for plan flow.

## Boot/test compatibility
- Existing boot scripts are unchanged.
- Structure guard remains integrated in `_BAT/6_run_tests.bat` and `tools/run_full_tests.py`.
